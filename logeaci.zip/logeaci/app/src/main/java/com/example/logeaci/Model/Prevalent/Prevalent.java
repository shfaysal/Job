package com.example.logeaci.Model.Prevalent;

import com.example.logeaci.Model.Users;

public class Prevalent {

    private static Users currentOnlineUsers;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";


}
