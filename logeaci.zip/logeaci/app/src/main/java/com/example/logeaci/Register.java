package com.example.logeaci;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Register extends AppCompatActivity {

    Button create_acc_btn;
    EditText inputName,inputPassword,inputphonenumber;
    private ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        create_acc_btn = findViewById(R.id.create_btn);

        inputName = findViewById(R.id.register_name_input);
        inputPassword = findViewById(R.id.register_password_input);
        inputphonenumber = findViewById(R.id.register_number_input);
        loading = new ProgressDialog(this);

        create_acc_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = inputName.getText().toString().trim();
                String password=inputPassword.getText().toString().trim();
                String phone = inputphonenumber.getText().toString().trim();

                if (name.isEmpty()){
                    inputphonenumber.setError("Name Empty");
                    inputphonenumber.requestFocus();
                    return;
                }else if(password.isEmpty()){
                    inputPassword.setError("Number Empty");
                    inputPassword.requestFocus();
                    return;
                }else if(phone.isEmpty()){
                    inputPassword.setError("Number Empty");
                    inputPassword.requestFocus();
                    return;
                }else{
                    loading.setTitle("Create Account");
                    loading.setMessage("Please wait, while we are checking credentials");
                    loading.setCanceledOnTouchOutside(false);
                    loading.show();

                    validatePhoneNumber(name,password,phone);
                }


            }
        });
    }

    private void validatePhoneNumber(final String name,final String password,final String phone) {

        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(!snapshot.child("Users").child(phone).exists()){
                    HashMap<String, Object> userDataMap = new HashMap<>();

                    userDataMap.put("phone",phone);
                    userDataMap.put("password",password);
                    userDataMap.put("name",name);

                    RootRef.child("Users").child(phone).updateChildren(userDataMap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(Register.this, "Successfully account created",Toast.LENGTH_SHORT).show();
                                        loading.dismiss();

                                        Intent intent = new Intent(Register.this,Login.class);
                                        startActivity(intent);
                                    }else{
                                        loading.dismiss();
                                        Toast.makeText(Register.this, "Network Error", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }else{
                    Toast.makeText(Register.this, "Mobile Number is already exists", Toast.LENGTH_SHORT).show();
                    loading.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Register.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });



    }
}