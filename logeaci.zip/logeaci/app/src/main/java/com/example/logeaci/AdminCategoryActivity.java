package com.example.logeaci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class AdminCategoryActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView tshirts, sportsTShirts, femaleDresses, sweathers;
    private ImageView glasses, hatscaps, walletBagsPurses, shoes;
    private ImageView headPhonesHandFree, laptops, watches, mobilePhones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_category);

        tshirts = findViewById(R.id.t_shirts);
        sportsTShirts = findViewById(R.id.sports_t_shirts);
        femaleDresses = findViewById(R.id.female_dresses);
        sweathers = findViewById(R.id.sweathers);
        glasses = findViewById(R.id.glasses);
        hatscaps = findViewById(R.id.hats_caps);
        walletBagsPurses = findViewById(R.id.purses_bags_wallets);
        shoes = findViewById(R.id.shoes);
        headPhonesHandFree = findViewById(R.id.headphones_handfree);
        laptops = findViewById(R.id.laptop_pc);
        watches = findViewById(R.id.watches);
        mobilePhones = findViewById(R.id.mobilephones);

        
        tshirts.setOnClickListener(this);
        sportsTShirts.setOnClickListener(this);
        femaleDresses.setOnClickListener(this);
        sweathers.setOnClickListener(this);
        glasses.setOnClickListener(this);
        hatscaps.setOnClickListener(this);
        walletBagsPurses.setOnClickListener(this);
        shoes.setOnClickListener(this);
        headPhonesHandFree.setOnClickListener(this);
        laptops.setOnClickListener(this);
        watches.setOnClickListener(this);
        mobilePhones.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.t_shirts:
                gotoAnotherActivity("tshirts");
                break;
            case  R.id.sports_t_shirts:
                gotoAnotherActivity("sportsTshirts");
                break;
            case R.id.female_dresses:
                gotoAnotherActivity("female Dresses");
                break;
            case R.id.sweathers:
                gotoAnotherActivity("sweaters");
                break;
            case  R.id.glasses:
                gotoAnotherActivity("glasses");
                break;
            case R.id.hats_caps:
                gotoAnotherActivity("hats caps");
                break;
            case R.id.purses_bags_wallets:
                gotoAnotherActivity("Parse");
                break;
            case R.id.shoes:
                gotoAnotherActivity("shoes");
                break;
            case R.id.headphones_handfree:
                gotoAnotherActivity("headphones");
                break;
            case R.id.laptop_pc:
                gotoAnotherActivity("laptop");
                break;
            case R.id.watches:
                gotoAnotherActivity("watches");
                break;
            case R.id.mobilephones:
                gotoAnotherActivity("mobile");
                break;
        }
    }

    private void gotoAnotherActivity(String category){
        Toast.makeText(this, category, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(AdminCategoryActivity.this, AdminAddNewProduct.class);
        intent.putExtra("category",category);
        startActivity(intent);
    }
}