package com.example.logeaci;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.logeaci.Model.Prevalent.Prevalent;
import com.example.logeaci.Model.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rey.material.widget.CheckBox;

import io.paperdb.Paper;

public class Login extends AppCompatActivity implements View.OnClickListener {

    EditText input_number,input_password;
    CheckBox cb_remember;
    TextView forget,not_admin,admin;
    ProgressDialog loadingBar;

    Button login;

    String parentDBName = "Users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        input_number = findViewById(R.id.login_number_input);
        input_password = findViewById(R.id.login_password_input);

        cb_remember = findViewById(R.id.cb_remember);
        login = findViewById(R.id.btn_login);

        forget = findViewById(R.id.tv_forget);
        not_admin = findViewById(R.id.not_tv_admin_panel);
        admin = findViewById(R.id.tv_admin_panel);

        loadingBar = new ProgressDialog(this);

        Paper.init(this);


        login.setOnClickListener(this);
        admin.setOnClickListener(this);
        not_admin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_login:
                gotoLogin();
                break;
            case R.id.tv_admin_panel:
                login.setText("Login Admin");
                admin.setVisibility(View.INVISIBLE);
                not_admin.setVisibility(View.VISIBLE);
                parentDBName = "Admins";
                break;
            case R.id.not_tv_admin_panel:
                login.setText("Login");
                not_admin.setVisibility(View.INVISIBLE);
                admin.setVisibility(View.VISIBLE);
                parentDBName = "Users";
                break;
        }
    }

    private void gotoLogin() {
        String phone = input_number.getText().toString().trim();
        String password = input_password.getText().toString().trim();

        if(TextUtils.isEmpty(phone)){
            Toast.makeText(this, "Please write your phone number", Toast.LENGTH_SHORT).show();
        }else  if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "Please write your password", Toast.LENGTH_SHORT).show();
        }else{
            loadingBar.setTitle("Login Account");
            loadingBar.setMessage("Please wait, while we are checking the creadentials");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();

            allowAccessAccount(phone,password);
        }

    }

    private void allowAccessAccount(String phone, String password) {

        if(cb_remember.isChecked()){
            Paper.book().write(Prevalent.UserPhoneKey, phone);
            Paper.book().write(Prevalent.UserPasswordKey, password);
        }
        final DatabaseReference Rootref;
        Rootref = FirebaseDatabase.getInstance().getReference();

        Rootref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(parentDBName).child(phone).exists()){
                    Users userData = snapshot.child(parentDBName).child(phone).getValue(Users.class);
                    if(userData.getPhone().equals(phone)){
                        if(userData.getPassword().equals(password)){
                            if(parentDBName.equals("Admins")){
                                Toast.makeText(Login.this, "Welcome Admin, you are logged in", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                                Intent intent = new Intent(Login.this,AdminCategoryActivity.class);
                                startActivity(intent);
                            }else if(parentDBName.equals("Users")){
                                loadingBar.dismiss();
                                Toast.makeText(Login.this, "Users Logged In Successfully", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(Login.this,HomeActivity.class);
                                startActivity(intent);

                            }
                        }else{
                            loadingBar.dismiss();
                            Toast.makeText(Login.this, "Wrong password", Toast.LENGTH_SHORT).show();
                        }
                    }
                    
                }else{
                    loadingBar.dismiss();
                    Toast.makeText(Login.this, "Phone number does not exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}